'''
   playing around with python sockets
'''

import socket, sys, os


